import React, { lazy, Suspense } from 'react';

const Dashboard = lazy(() => import ('./pages/dashboard'));